from functions.database import database as db
from disnake.ext import commands, tasks
import disnake
import asyncio
import base64
import copy
import os
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'))

_DEFERRED_TASK_START_PATCHED = False


def _apply_deferred_task_start_patch():
    global _DEFERRED_TASK_START_PATCHED
    if _DEFERRED_TASK_START_PATCHED:
        return
    _DEFERRED_TASK_START_PATCHED = True

    original_start = tasks.Loop.start

    def safe_start(loop_self, *args, **kwargs):
        try:
            asyncio.get_running_loop()
        except RuntimeError as exc:
            if "no running event loop" not in str(exc).lower() and "no current event loop" not in str(exc).lower():
                raise

            cog = getattr(loop_self, "_injected", None)
            bot = getattr(cog, "bot", None)
            if bot is None or not hasattr(bot, "add_listener"):
                raise

            flag_name = "_system_deferred_start_registered"
            if getattr(loop_self, flag_name, False):
                return None
            setattr(loop_self, flag_name, True)

            async def start_after_ready():
                if getattr(loop_self, "_system_deferred_start_done", False):
                    return
                setattr(loop_self, "_system_deferred_start_done", True)

                try:
                    bot.remove_listener(start_after_ready, "on_ready")
                except Exception:
                    pass

                if not loop_self.is_running():
                    original_start(loop_self, *args, **kwargs)

            bot.add_listener(start_after_ready, "on_ready")
            return None

        return original_start(loop_self, *args, **kwargs)

    tasks.Loop.start = safe_start


def _first_env(*names: str) -> str:
    for name in names:
        value = os.getenv(name)
        if value:
            return value.strip()
    return ""


def _bot_id_from_token(token: str) -> str:
    token = str(token or "").strip()
    if "." not in token:
        return ""
    first_part = token.split(".", 1)[0]
    try:
        padding = "=" * ((4 - len(first_part) % 4) % 4)
        decoded = base64.urlsafe_b64decode((first_part + padding).encode()).decode()
        return decoded if decoded.isdigit() else ""
    except Exception:
        return ""


def create_bot() -> tuple[commands.Bot, str, str]:
    token = _first_env("BOT_TOKEN", "DISCORD_BOT_TOKEN", "TOKEN", "DISCORD_TOKEN")
    if not token:
        raise RuntimeError("BOT_TOKEN nao informado. Configure a variavel de ambiente BOT_TOKEN na hospedagem.")

    bot_id = _first_env("BOT_ID", "CLIENT_ID", "APPLICATION_CLIENT_ID") or _bot_id_from_token(token)
    owner = _first_env("OWNER_ID", "OWNERID", "OWNER", "BOT_OWNER")
    server = _first_env("BOT_SERVER_ID", "SERVER_ID", "GUILD_ID")

    info = {
        "token": token,
        "id": str(bot_id or ""),
        "owner": str(owner or ""),
        "server": str(server or ""),
        "perms": [],
        "version": "Bot V12.5",
    }

    config_db = db.obter("config.json")
    persisted_config = copy.deepcopy(config_db)
    persisted_config["botToken"] = ""
    persisted_bot = copy.deepcopy(info)
    persisted_bot["token"] = ""
    persisted_config["botID"] = info["id"]
    persisted_config["bot"] = persisted_bot
    persisted_config["syncEmojis"] = False
    db.salvar("config.json", persisted_config)

    intents = disnake.Intents.default()
    intents.message_content = True
    intents.members = True
    intents.guilds = True

    bot = commands.Bot(
        command_prefix=commands.when_mentioned,
        intents=intents,
        help_command=None,
        reload=True
    )
    _apply_deferred_task_start_patch()
    return bot, info["token"], info["id"]