"""Compatibilidade: o sistema de Keys foi movido para modules.keys."""
from modules.keys.cog import *
from modules.keys.cog import KeysPanel

__all__ = ["KeysPanel"]
