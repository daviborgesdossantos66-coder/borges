def setup(bot):
    # Modulo mantido para compatibilidade.
    # Sem cog ativo, o checkout usa o fallback de recibo publico.
    return None
