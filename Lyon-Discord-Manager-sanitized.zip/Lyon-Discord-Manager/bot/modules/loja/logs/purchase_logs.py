class PurchaseLogsLyon:
    async def send_purchase_event_bulk(self, *args, **kwargs):
        return False
