"""
Sistema de Cashback
"""
from .cog import CashbackLyon, setup
from .manager import CashbackManager

__all__ = ["CashbackLyon", "CashbackManager", "setup"]
