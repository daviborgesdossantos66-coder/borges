"""Sistema modular de Keys."""
from .cog import KeysPanel

__all__ = ["KeysPanel"]
