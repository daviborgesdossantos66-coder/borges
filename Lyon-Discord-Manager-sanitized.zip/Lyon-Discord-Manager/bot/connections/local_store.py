"""Small Mongo-like JSON store used when no MongoDB URI is configured.

The bot already models its data as documents keyed by ``_id``.  This adapter
keeps that interface for local development and single-instance deployments,
without requiring an external database.
"""

from __future__ import annotations

import copy
import json
import os
import threading
from pathlib import Path
from typing import Any, Iterable


class _AwaitableValue:
    def __init__(self, value: Any):
        self.value = value

    def __await__(self):
        async def _return():
            return self.value

        return _return().__await__()

    def __bool__(self) -> bool:
        return bool(self.value)


class _AwaitableDocument(dict):
    """A dict that can also be awaited by legacy async cogs."""

    def __await__(self):
        async def _return():
            return self

        return _return().__await__()


class _AwaitableNone(_AwaitableValue):
    def __init__(self):
        super().__init__(None)


class LocalCollection:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._ensure_file()

    def _ensure_file(self) -> None:
        if not self.path.exists():
            self._write({})

    def _read(self) -> dict[str, dict[str, Any]]:
        try:
            with self.path.open("r", encoding="utf-8") as file:
                data = json.load(file)
            return data if isinstance(data, dict) else {}
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}

    def _write(self, data: dict[str, dict[str, Any]]) -> None:
        temp = self.path.with_suffix(f"{self.path.suffix}.tmp")
        with temp.open("w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2, default=str)
        os.replace(temp, self.path)

    @staticmethod
    def _get(document: dict[str, Any], path: str) -> Any:
        value: Any = document
        for part in path.split("."):
            if not isinstance(value, dict) or part not in value:
                return None
            value = value[part]
        return value

    @classmethod
    def _matches(cls, document: dict[str, Any], query: dict[str, Any]) -> bool:
        for key, expected in (query or {}).items():
            actual = cls._get(document, key)
            if isinstance(expected, dict) and "$in" in expected:
                if actual not in expected["$in"]:
                    return False
            elif actual != expected:
                return False
        return True

    @classmethod
    def _project(cls, document: dict[str, Any], projection: dict[str, Any] | None):
        if not projection:
            return _AwaitableDocument(copy.deepcopy(document))
        included = [key for key, value in projection.items() if value and key != "_id"]
        if not included:
            return _AwaitableDocument(copy.deepcopy(document))

        result: dict[str, Any] = {}
        if projection.get("_id", 1) and "_id" in document:
            result["_id"] = document["_id"]
        for key in included:
            value = cls._get(document, key)
            if value is None:
                continue
            cursor = result
            parts = key.split(".")
            for part in parts[:-1]:
                cursor = cursor.setdefault(part, {})
            cursor[parts[-1]] = copy.deepcopy(value)
        return _AwaitableDocument(result)

    @staticmethod
    def _set(document: dict[str, Any], path: str, value: Any) -> None:
        parts = path.split(".")
        cursor = document
        for part in parts[:-1]:
            current = cursor.get(part)
            if not isinstance(current, dict):
                current = {}
                cursor[part] = current
            cursor = current
        cursor[parts[-1]] = copy.deepcopy(value)

    @classmethod
    def _unset(cls, document: dict[str, Any], path: str) -> None:
        parts = path.split(".")
        cursor: Any = document
        for part in parts[:-1]:
            cursor = cursor.get(part) if isinstance(cursor, dict) else None
        if isinstance(cursor, dict):
            cursor.pop(parts[-1], None)

    @classmethod
    def _inc(cls, document: dict[str, Any], path: str, amount: Any) -> None:
        current = cls._get(document, path)
        cls._set(document, path, (current or 0) + amount)

    @classmethod
    def _push(cls, document: dict[str, Any], path: str, value: Any) -> None:
        current = cls._get(document, path)
        if not isinstance(current, list):
            current = []
            cls._set(document, path, current)
        current.append(copy.deepcopy(value))

    @classmethod
    def _apply_update(
        cls, document: dict[str, Any], update: dict[str, Any], inserting: bool = False
    ) -> None:
        if not any(key.startswith("$") for key in update):
            document.clear()
            document.update(copy.deepcopy(update))
            return
        if inserting:
            for path, value in update.get("$setOnInsert", {}).items():
                cls._set(document, path, value)
        for path, value in update.get("$set", {}).items():
            cls._set(document, path, value)
        for path, value in update.get("$inc", {}).items():
            cls._inc(document, path, value)
        for path, value in update.get("$push", {}).items():
            cls._push(document, path, value)
        for path in update.get("$unset", {}):
            cls._unset(document, path)

    def find_one(self, query: dict[str, Any], projection: dict[str, Any] | None = None):
        with self._lock:
            for document in self._read().values():
                if self._matches(document, query):
                    return self._project(document, projection)
        return _AwaitableNone()

    def find(self, query: dict[str, Any] | None = None, projection: dict[str, Any] | None = None):
        query = query or {}
        with self._lock:
            return [
                self._project(document, projection)
                for document in self._read().values()
                if self._matches(document, query)
            ]

    def replace_one(self, query: dict[str, Any], replacement: dict[str, Any], upsert: bool = False):
        with self._lock:
            data = self._read()
            key = str(query.get("_id", ""))
            if key not in data and not upsert:
                return _AwaitableValue(None)
            replacement = copy.deepcopy(replacement)
            replacement.setdefault("_id", key)
            data[str(replacement["_id"])] = replacement
            self._write(data)
        return _AwaitableValue(None)

    def insert_one(self, document: dict[str, Any]):
        with self._lock:
            data = self._read()
            item = copy.deepcopy(document)
            key = str(item.get("_id") or len(data))
            item["_id"] = key
            data[key] = item
            self._write(data)
        return _AwaitableValue(None)

    def update_one(self, query: dict[str, Any], update: dict[str, Any], upsert: bool = False):
        with self._lock:
            data = self._read()
            key = str(query.get("_id", ""))
            document = data.get(key)
            inserting = document is None
            if inserting and not upsert:
                return _AwaitableValue(None)
            document = copy.deepcopy(document or {"_id": key})
            self._apply_update(document, update, inserting=inserting)
            data[key] = document
            self._write(data)
        return _AwaitableValue(None)

    def delete_one(self, query: dict[str, Any]):
        with self._lock:
            data = self._read()
            for key, document in list(data.items()):
                if self._matches(document, query):
                    del data[key]
                    self._write(data)
                    break
        return _AwaitableValue(None)

    def delete_many(self, query: dict[str, Any]):
        with self._lock:
            data = self._read()
            for key in list(data):
                if self._matches(data[key], query):
                    del data[key]
            self._write(data)
        return _AwaitableValue(None)


class LocalDatabase:
    def __init__(self, path: Path):
        self.collection = LocalCollection(path)

    def command(self, *_args: Any, **_kwargs: Any) -> dict[str, int]:
        return {"ok": 1}
