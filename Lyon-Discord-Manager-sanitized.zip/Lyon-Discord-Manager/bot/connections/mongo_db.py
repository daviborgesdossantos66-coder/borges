"""Database connection with MongoDB when configured, otherwise local JSON storage."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

from connections.local_store import LocalDatabase


BASE_DIR = Path(__file__).resolve().parents[1]
CONFIG_PATH = BASE_DIR / "configs" / "config_mongo.json"


def _read_config() -> dict[str, Any]:
    try:
        with CONFIG_PATH.open("r", encoding="utf-8") as file:
            value = json.load(file)
        return value if isinstance(value, dict) else {}
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def _first_env(*names: str) -> str:
    for name in names:
        value = os.getenv(name, "").strip()
        if value:
            return value
    return ""


def _resolve_settings() -> tuple[str, str, str]:
    config = _read_config()
    mongo_config = config.get("mongo", config)
    if not isinstance(mongo_config, dict):
        mongo_config = {}
    mongo_url = _first_env("MONGO_URL", "MONGODB_URI", "MONGO_URI") or str(
        mongo_config.get("mongoURL") or mongo_config.get("uri") or ""
    ).strip()
    if mongo_url.lower() in {
        "nao tenho",
        "não tenho",
        "nao configurado",
        "não configurado",
        "none",
        "null",
        "local",
        "disabled",
    }:
        mongo_url = ""
    database_name = _first_env("MONGO_DATABASE", "MONGODB_DATABASE") or str(
        mongo_config.get("databaseName") or "botnew"
    ).strip()
    collection_name = _first_env("MONGO_COLLECTION", "MONGODB_COLLECTION") or str(
        mongo_config.get("collectionName") or "documents"
    ).strip()
    return mongo_url, database_name, collection_name


MONGO_URL, DATABASE_NAME, COLLECTION_NAME = _resolve_settings()
_local_data_dir = Path(
    _first_env("SYSTEMPRO_DATA_DIR", "SYSTEM_DATA_DIR", "PERSISTENT_DATA_DIR", "DATA_DIR")
    or (BASE_DIR / "database")
)

if MONGO_URL:
    from pymongo import MongoClient
    from pymongo.errors import PyMongoError

    max_retries = int(os.getenv("MONGO_CONNECT_RETRIES", "5"))
    retry_delay = int(os.getenv("MONGO_CONNECT_RETRY_DELAY", "5"))

    client = MongoClient(
        MONGO_URL,
        serverSelectionTimeoutMS=int(os.getenv("MONGO_SERVER_SELECTION_TIMEOUT_MS", "5000")),
        connectTimeoutMS=int(os.getenv("MONGO_CONNECT_TIMEOUT_MS", "5000")),
        socketTimeoutMS=int(os.getenv("MONGO_SOCKET_TIMEOUT_MS", "10000")),
        retryWrites=True,
        serverSelectionTimeoutMS=max(
            int(os.getenv("MONGO_SERVER_SELECTION_TIMEOUT_MS", "5000")),
            retry_delay * 1000,
        ),
    )

    _mongo_ready = False
    for attempt in range(1, max_retries + 1):
        try:
            client.admin.command("ping")
            _mongo_ready = True
            break
        except PyMongoError as exc:
            print(f"[Database] Tentativa {attempt}/{max_retries} de conectar ao MongoDB falhou: {exc}")
            if attempt < max_retries:
                time.sleep(retry_delay)
            else:
                print("[Database] Todos os tentativas de conexao ao MongoDB falharam. Usando armazenamento local.")

    if _mongo_ready:
        database = client[DATABASE_NAME]
        collection = database[COLLECTION_NAME]
        print(f"[Database] MongoDB conectado: database={DATABASE_NAME!r}, collection={COLLECTION_NAME!r}")
    else:
        client = LocalDatabase(_local_data_dir / "local_documents.json")
        database = client
        collection = client.collection
        print(f"[Database] MongoDB indisponivel; usando armazenamento local em {_local_data_dir}")
else:
    client = LocalDatabase(_local_data_dir / "local_documents.json")
    database = client
    collection = client.collection
    print(f"[Database] MongoDB não configurado; usando armazenamento local em {_local_data_dir}")

bot_collection = collection

__all__ = [
    "client",
    "database",
    "collection",
    "bot_collection",
    "MONGO_URL",
    "DATABASE_NAME",
    "COLLECTION_NAME",
]