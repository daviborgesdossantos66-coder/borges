import json
import os
import time
import threading
import copy
from typing import Optional, Any
from pathlib import Path


class database:
    _cache: dict[str, tuple[Any, float]] = {}
    _cache_lock = threading.Lock()
    _default_ttl = 60
    
    _long_cache_docs = {
        "custom_mode",
        "custom_panel_mode",
        "custom_colors",
        "canais",
    }
    _long_cache_ttl = 300

    _file_cache: dict[str, tuple[Any, float]] = {}
    _file_cache_lock = threading.Lock()
    _file_cache_ttl = 60

    _protected_persistent_docs = {
        "loja_products",
        "products",
        "loja_buys",
        "loja_customers",
        "loja_data",
        "loja_preferences",
        "loja_stock_notifications",
        "loja_stock_requests",
        "loja_mass_coupons",
        "loja_roles_temp",
        "stock_config",
        "products_preferences",
        "blacklist",
        "whitelist",
        "protection_advanced_security",
        "protection_privatizacoes_apps",
        "protection_privatizacoes_cargos",
        "protection_privatizacoes_mencoes",
        "protection_privatizacoes_perms",
        "protection_privatizacoes_persistencia",
        "protection_privatizacoes_urls",
        "protection_protecaogeral_banimentos",
        "protection_protecaogeral_canais",
        "protection_protecaogeral_cargos",
        "protection_protecaogeral_comandosext",
        "protection_protecaogeral_expulsoes",
        "protection_protecaogeral_webhooks",
        "antifake_logs",
        "antifake_authorized",
        "protection_config",
        "antifake_config",
        "advanced_security_config",
    }

    @staticmethod
    def _data_dir() -> Path:
        base_dir = Path(__file__).resolve().parent.parent
        candidates = [
            os.getenv("SYSTEMPRO_DATA_DIR"),
            os.getenv("SYSTEM_DATA_DIR"),
            os.getenv("PERSISTENT_DATA_DIR"),
            os.getenv("DATA_DIR"),
            os.getenv("CAMPOSCLOUD_DATA_DIR"),
            "/data/systempro",
            "/app/data/systempro",
            base_dir.parent / "data" / "systempro",
            base_dir / "database",
        ]
        for candidate in candidates:
            path = Path(str(candidate or "").strip())
            if not path:
                continue
            try:
                path.mkdir(parents=True, exist_ok=True)
                probe = path / ".write-test"
                probe.write_text("ok", encoding="utf-8")
                probe.unlink(missing_ok=True)
                return path
            except Exception:
                continue
        fallback = base_dir / "database"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback

    @staticmethod
    def _doc_path(config_type: str) -> Path:
        return database._data_dir() / f"{config_type}.json"

    @staticmethod
    def _legacy_path(filename: str) -> Path:
        base_dir = Path(__file__).resolve().parent.parent
        return base_dir / filename

    @staticmethod
    def _payload_from_document(document):
        if not document:
            return None
        try:
            doc_copy = document.copy()
        except Exception:
            try:
                doc_copy = dict(document)
            except Exception:
                return None
        doc_copy.pop("_id", None)
        if len(doc_copy) == 1 and "items" in doc_copy:
            return doc_copy.get("items")
        if len(doc_copy) == 1 and "value" in doc_copy:
            return doc_copy.get("value")
        return doc_copy

    @staticmethod
    def _is_empty_persistent_data(data):
        if data is None:
            return True
        if isinstance(data, (list, tuple, set)):
            return len(data) == 0
        if isinstance(data, dict):
            clean = {k: v for k, v in data.items() if k != "_id"}
            if not clean:
                return True
            if set(clean.keys()) == {"items"}:
                return database._is_empty_persistent_data(clean.get("items"))
            if set(clean.keys()) == {"value"}:
                return database._is_empty_persistent_data(clean.get("value"))
            return False
        return False

    @staticmethod
    def _normalize_custom_mode(data):
        if not isinstance(data, dict):
            data = {}
        result = copy.deepcopy(data)
        style = str(result.get("style") or result.get("bot_style") or "").lower().strip()
        mode = str(result.get("mode") or "").lower().strip()
        aliases = {
            "components": "full_v2",
            "componentes": "full_v2",
            "components_v2": "full_v2",
            "componentes_v2": "full_v2",
            "container": "full_v2",
            "containers": "full_v2",
            "full_components": "full_v2",
            "full_components_v2": "full_v2",
            "full components v2": "full_v2",
            "full comp v2": "full_v2",
            "full_comp_v2": "full_v2",
            "full_v2": "full_v2",
            "embed": "embed",
            "embeds": "embed",
            "embed_v1": "embed",
            "hybrid": "hybrid",
            "hibrido": "hybrid",
            "comp v2 + embed": "hybrid",
            "compv2 + embed": "hybrid",
            "components v2 + embed": "hybrid",
            "embed + comp v2": "hybrid",
            "embed + components v2": "hybrid",
            "comp v2 embed": "hybrid",
            "compv2 embed": "hybrid",
            "comp_v2_embed": "hybrid",
            "compv2_embed": "hybrid",
            "components_embed": "hybrid",
            "embed_components": "hybrid",
            "embed_components_v2": "hybrid",
            "embed_comp_v2": "hybrid",
        }
        style = aliases.get(style)
        if style is None:
            style = "embed" if mode == "embed" else "full_v2"
        result["style"] = style
        result["mode"] = "embed" if style == "embed" else "components"
        return result

    @staticmethod
    def _normalize_custom_panel_mode(data):
        if not isinstance(data, dict):
            data = {}
        result = copy.deepcopy(data)
        panel_mode = str(result.get("mode") or result.get("layout") or "").lower().strip()
        aliases = {
            "button": "buttons",
            "buttons": "buttons",
            "botao": "buttons",
            "botoes": "buttons",
            "botões": "buttons",
            "select": "select",
            "select_menu": "select",
            "menu": "select",
            "both": "both",
            "ambos": "both",
            "complete": "both",
            "completo": "both",
        }
        result["mode"] = aliases.get(panel_mode, "both")
        return result

    @staticmethod
    def _default_document(config_type: str):
        if config_type == "custom_mode":
            return {"mode": "components", "style": "full_v2"}
        if config_type == "custom_panel_mode":
            return {"mode": "both"}
        return {}

    @staticmethod
    def _normalize_document(config_type: str, data):
        if config_type == "custom_mode":
            return database._normalize_custom_mode(data)
        if config_type == "custom_panel_mode":
            return database._normalize_custom_panel_mode(data)
        return data

    @staticmethod
    def _inject_runtime_credentials(filename: str, data):
        if os.path.normpath(str(filename)) != "config.json" or not isinstance(data, dict):
            return data
        token = next(
            (
                os.getenv(name, "").strip()
                for name in ("DISCORD_BOT_TOKEN", "BOT_TOKEN", "TOKEN", "DISCORD_TOKEN")
                if os.getenv(name, "").strip()
            ),
            "",
        )
        if not token:
            return data
        result = copy.deepcopy(data)
        result["botToken"] = token
        result["bot"] = dict(result.get("bot") or {})
        result["bot"]["token"] = token
        return result

    @staticmethod
    def _read_json_file(path: Path):
        try:
            with path.open("r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return None

    @staticmethod
    def _write_json_file(path: Path, data):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(f"{path.suffix}.tmp")
        with temp.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4, default=str)
        os.replace(temp, path)

    @staticmethod
    def obter(filename: str):
        current_time = time.time()
        with database._file_cache_lock:
            cached = database._file_cache.get(filename)
            if cached:
                data, expiry = cached
                if current_time < expiry:
                    return database._inject_runtime_credentials(filename, copy.deepcopy(data))
                database._file_cache.pop(filename, None)

        path = database._legacy_path(filename)
        data = database._read_json_file(path)
        if data is not None:
            with database._file_cache_lock:
                database._file_cache[filename] = (copy.deepcopy(data), current_time + database._file_cache_ttl)
            return database._inject_runtime_credentials(filename, data)

        print(f"[Database] Arquivo legado não encontrado: {filename}")
        return {}

    @staticmethod
    def salvar(filename: str, data):
        path = database._legacy_path(filename)
        try:
            database._write_json_file(path, data)
            with database._file_cache_lock:
                database._file_cache[filename] = (copy.deepcopy(data), time.time() + database._file_cache_ttl)
            return True
        except Exception as e:
            print(f"[Database] Erro ao salvar '{filename}': {type(e).__name__} - {e}")
            return False

    @staticmethod
    def get_document(config_type: str):
        current_time = time.time()
        
        with database._cache_lock:
            if config_type in database._cache:
                cached_data, expiry_time = database._cache[config_type]
                if current_time < expiry_time:
                    return copy.deepcopy(cached_data)

        path = database._doc_path(config_type)
        data = database._read_json_file(path)
        
        if data is not None:
            doc_copy = data.copy() if isinstance(data, dict) else data
            if isinstance(doc_copy, dict):
                doc_copy.pop("_id", None)
                if len(doc_copy) == 1 and "items" in doc_copy:
                    result = doc_copy["items"]
                elif len(doc_copy) == 1 and "value" in doc_copy:
                    result = doc_copy["value"]
                else:
                    result = doc_copy
            else:
                result = doc_copy
            result = database._normalize_document(config_type, result)
            
            cached_result = copy.deepcopy(result)
            ttl = database._long_cache_ttl if config_type in database._long_cache_docs else database._default_ttl
            with database._cache_lock:
                database._cache[config_type] = (cached_result, current_time + ttl)
            return copy.deepcopy(result)

        empty_result = database._default_document(config_type)
        with database._cache_lock:
            database._cache[config_type] = (empty_result, current_time + 10)
        return copy.deepcopy(empty_result)

    @staticmethod
    def get_documents(query: dict = None):
        if query is None:
            query = {}
        results = []
        data_dir = database._data_dir()
        for path in data_dir.glob("*.json"):
            config_type = path.stem
            if config_type.startswith("_"):
                continue
            doc = database._read_json_file(path)
            if doc and database._matches(doc, query):
                doc_copy = doc.copy()
                doc_copy.pop("_id", None)
                results.append(doc_copy)
        return results

    @staticmethod
    def _matches(document: dict, query: dict) -> bool:
        for key, expected in (query or {}).items():
            actual = document.get(key)
            if isinstance(expected, dict) and "$in" in expected:
                if actual not in expected["$in"]:
                    return False
            elif actual != expected:
                return False
        return True

    @staticmethod
    def delete_document(config_type: str):
        path = database._doc_path(config_type)
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass
        with database._cache_lock:
            database._cache.pop(config_type, None)

    @staticmethod
    def delete_documents(query: dict):
        data_dir = database._data_dir()
        for path in data_dir.glob("*.json"):
            config_type = path.stem
            if config_type.startswith("_"):
                continue
            doc = database._read_json_file(path)
            if doc and database._matches(doc, query):
                try:
                    path.unlink(missing_ok=True)
                except Exception:
                    pass
                with database._cache_lock:
                    database._cache.pop(config_type, None)

    @staticmethod
    def save_document(config_type: str, query_or_data=None, data=None):
        if data is None:
            data = query_or_data
        
        data = database._normalize_document(config_type, data)
        path = database._doc_path(config_type)

        if isinstance(data, list):
            document = {"_id": config_type, "items": data}
            cache_data = data
        elif isinstance(data, dict):
            data_copy = data.copy()
            data_copy["_id"] = config_type
            document = data_copy
            cache_data = {k: v for k, v in data_copy.items() if k != "_id"}
            if len(cache_data) == 1 and "items" in cache_data:
                cache_data = cache_data["items"]
        else:
            document = {"_id": config_type, "value": data}
            cache_data = data

        if config_type in database._protected_persistent_docs and database._is_empty_persistent_data(cache_data):
            existing_data = database._read_json_file(path)
            existing_payload = database._payload_from_document(existing_data)
            if not database._is_empty_persistent_data(existing_payload):
                print(f"[Database] Protecao ativa: ignorando tentativa de salvar '{config_type}' vazio para nao perder dados.")
                current_time = time.time()
                ttl = database._long_cache_ttl if config_type in database._long_cache_docs else database._default_ttl
                with database._cache_lock:
                    database._cache[config_type] = (copy.deepcopy(existing_payload), current_time + ttl)
                return

        database._write_json_file(path, document)
        
        current_time = time.time()
        ttl = database._long_cache_ttl if config_type in database._long_cache_docs else database._default_ttl
        cached_data = copy.deepcopy(cache_data)
        with database._cache_lock:
            database._cache[config_type] = (cached_data, current_time + ttl)

    @staticmethod
    def initialize_database_if_needed():
        init_marker = database._data_dir() / "_meta_initialization.json"
        if init_marker.exists():
            return

        print("Primeira inicialização detectada. Criando arquivos de configuração padrão...")

        template_file = database._legacy_path("database_template.json")
        
        try:
            with template_file.open("r", encoding="utf-8") as f:
                all_configs = json.load(f)
            
            for config_type, default_data in all_configs.items():
                try:
                    if isinstance(default_data, list):
                        database.save_document(config_type, {"items": default_data})
                        print(f" - Config '{config_type}' inicializada com {len(default_data)} itens.")
                    else:
                        database.save_document(config_type, default_data)
                        print(f" - Config '{config_type}' inicializada com sucesso.")
                except Exception as e:
                    print(f"Erro ao inicializar a config '{config_type}': {e}")
            
            init_marker.write_text(json.dumps({"initialized_at": time.time()}), encoding="utf-8")
            print("Inicialização da base de dados local concluída.")
        
        except FileNotFoundError:
            print(f"ERRO: Arquivo '{template_file}' não encontrado!")
        except json.JSONDecodeError as e:
            print(f"ERRO: Arquivo '{template_file}' contém JSON inválido: {e}")

    @staticmethod
    def verify_and_create_missing_documents():
        template_file = database._legacy_path("database_template.json")
        
        try:
            with template_file.open("r", encoding="utf-8") as f:
                all_configs = json.load(f)
            
            missing_count = 0
            for config_type, default_data in all_configs.items():
                path = database._doc_path(config_type)
                if not path.exists():
                    try:
                        if isinstance(default_data, list):
                            database.save_document(config_type, {"items": default_data})
                            print(f"[LocalDB] Documento faltante '{config_type}' criado com {len(default_data)} itens.")
                        else:
                            database.save_document(config_type, default_data)
                            print(f"[LocalDB] Documento faltante '{config_type}' criado com sucesso.")
                        missing_count += 1
                    except Exception as e:
                        print(f"[LocalDB] Erro ao criar documento '{config_type}': {e}")
            
            if missing_count > 0:
                print(f"[LocalDB] {missing_count} documento(s) faltante(s) foi(ram) criado(s).")
            else:
                print("[LocalDB] Todos os documentos do template estão presentes na base local.")
        
        except FileNotFoundError:
            print(f"[LocalDB] ERRO: Arquivo '{template_file}' não encontrado!")
        except json.JSONDecodeError as e:
            print(f"[LocalDB] ERRO: Arquivo '{template_file}' contém JSON inválido: {e}")
        except Exception as e:
            print(f"[LocalDB] ERRO ao verificar documentos: {e}")
    
    @staticmethod
    def clear_cache(config_type: Optional[str] = None):
        with database._cache_lock:
            if config_type:
                database._cache.pop(config_type, None)
            else:
                database._cache.clear()
    
    @staticmethod
    def get_cache_stats() -> dict:
        with database._cache_lock:
            current_time = time.time()
            valid_entries = sum(1 for _, (_, expiry) in database._cache.items() if current_time < expiry)
            expired_entries = len(database._cache) - valid_entries
            return {
                "total_entries": len(database._cache),
                "valid_entries": valid_entries,
                "expired_entries": expired_entries,
                "cached_documents": list(database._cache.keys())
            }