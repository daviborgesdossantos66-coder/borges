"""Local alias for asyncio used by this project."""

from asyncio import *
