---
name: Bot persistence
description: Durable storage and credential handling for the Discord bot.
---

MongoDB is optional in this project. When no valid MongoDB URI is available, use the local JSON document store so the bot can start and preserve configuration in a single-instance deployment. Discord, database, AI, and integration credentials belong in Replit Secrets, never in the checked-in JSON files.

**Why:** The uploaded package contained embedded credentials and the user does not have a MongoDB URI. Keeping startup independent from an external database makes the bot usable while preventing secrets from being committed.

**How to apply:** Keep `MONGO_URL` optional, validate placeholder values such as “não tenho” as absent, and use the existing local persistence path. Treat emoji synchronization and cloud/payment/AI integrations as opt-in until their credentials are configured.